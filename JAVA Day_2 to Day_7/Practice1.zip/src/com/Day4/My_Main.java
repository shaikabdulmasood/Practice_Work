package com.Day4;
import java.util.Scanner;

public class My_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter first number: ");
        double a = sc.nextDouble();

        System.out.print("Enter second number: ");
        double b = sc.nextDouble();
        
        My_Operations add = (x, y) -> x + y;
        System.out.println("Addition: " + add.calculate(a, b));
        My_Operations subtract = (x, y) -> x - y;
        System.out.println("Subtraction: " + subtract.calculate(a, b));

        My_Operations multiply = (x, y) -> x * y;
        System.out.println("Multiplication: " + multiply.calculate(a, b));
        
        }

	public void show() {
		// TODO Auto-generated method stub
		System.out.println("HI am My_Main Class");
	}

}
