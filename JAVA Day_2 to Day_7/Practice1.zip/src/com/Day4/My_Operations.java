package com.Day4;

public interface My_Operations {
    double calculate(double x, double y);
}