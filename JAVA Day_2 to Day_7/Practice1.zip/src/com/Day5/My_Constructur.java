package com.Day5;

public class My_Constructur {

	    int a;
	    int b;

	    // Constructor
	    My_Constructur(int a, int b) {
	        this.a = a;
	        this.b = b;
	    }

	    // Copy Constructor
	    My_Constructur(My_Constructur c) {
	        this.b = c.a;
	        this.a = c.b;
	    }

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		My_Constructur b1 = new My_Constructur(100,300);
		My_Constructur b2 = new My_Constructur(b1);
        System.out.println(b2.a);
	}
}
