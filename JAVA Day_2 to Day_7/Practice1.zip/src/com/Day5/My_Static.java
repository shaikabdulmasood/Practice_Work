package com.Day5;

public class My_Static {
	
	void adds(int a, int b) {
		System.out.println("Hi i am instance");
	}
	
	static class my_Static_class{
	static void add(int a, int b) {
		System.out.println("Hi i am static"+a);
	}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		My_Static.add.My_Static_Class(2,3);
		
	}

}
