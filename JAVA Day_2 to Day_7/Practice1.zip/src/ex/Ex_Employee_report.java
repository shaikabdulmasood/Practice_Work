package ex;

public class Ex_Employee_report {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
StringBuffer report = new StringBuffer();
		
		report.append("==========       Employee Report     ===========\n");
		report.append("Id     Name           Department          Salary\n");
		report.append("01     Jack            Java			 200000.00\n");
		report.append("02     Devil           C++			 300000.00\n");
		
		System.out.println(report.toString());
		report.insert("03     Masood          SQL            400000.00\n");
		
		
	}
		
}
