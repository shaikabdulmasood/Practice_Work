package ex;

public class Ex_Array {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		String [] Fruits = {"Mango","Apple","Banana","Kivi"};
		int [] Price = {60,50,10,40};
		System.out.println("Fruuits are ");
		for(int i = 0; i < Fruits.length ; i++)
		{
			System.out.println(Fruits[i]+" cost is "+Price[i]);
		}

	}

}
