package Day_3;

public class My_bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Bank_account bk = new Bank_account(500);
		
		System.out.println("Current Balance: " + bk.getBalance());
		
		bk.deposite(1000);
		System.out.println("Current Balance: " + bk.getBalance());
		bk.withdraw(500);
		System.out.println("Current Balance: " + bk.getBalance());
		bk.withdraw(1600);
		System.out.println("Current Balance: " + bk.getBalance());
		bk.deposite(-50);
		
        System.out.println("Final Balance: " + bk.getBalance());


	}

}
