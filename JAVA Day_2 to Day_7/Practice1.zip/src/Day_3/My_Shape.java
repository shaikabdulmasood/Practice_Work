package Day_3;

public class My_Shape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Abstract_Shape s1 = new Circle();
        System.out.println("Circle Area: " + s1.area());

        Abstract_Shape s2 = new Rectangle();
        System.out.println("Rectangle Area: " + s2.area());
	}

}
