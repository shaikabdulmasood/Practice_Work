package Day_3;

public class Employee_info {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee emp = new Employee("Alice", 30000);
		
		System.out.println("Employee Name: " + emp.getName());
        System.out.println("Current Salary: " + emp.getSalary());

        emp.setSalary(35000);
        System.out.println("Updated Salary: " + emp.getSalary());

        emp.setSalary(-5000);
        System.out.println("After Invalid Update: " + emp.getSalary());
	}

}
