package Day3_Inheritance;

public class My_Account {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 SavingsAccount sa = new SavingsAccount();
	        sa.displayBalance(1000);
	        sa.addInterest();

	        CurrentAccount ca = new CurrentAccount();
	        ca.displayBalance(1000);
	        ca.noInterest();
	}

}
