package Day3_Inheritance;

public class My_Person {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s = new Student();
        s.study();

        Teacher t = new Teacher();
        t.teach();
	}

}
