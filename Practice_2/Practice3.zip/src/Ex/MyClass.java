package Ex;

public class MyClass {
	
	void sound() {
		System.out.println("Hello i am Runtime_poly class");
	}
}
class My_rp extends MyClass
{
	
	void sound()
	{
		System.out.println("HI i am rp class");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClass rps = new My_rp();
		rps.sound();

	}

}
