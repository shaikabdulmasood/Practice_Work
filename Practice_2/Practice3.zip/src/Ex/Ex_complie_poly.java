package Ex;

public class Ex_complie_poly {
	
	void add(int a,int b,int c) {
		int sum = a+b+c;
		System.out.println("sum of "+a+"+"+b+"+"+c+ " is : "+sum);
	}
	void add(int a, int b) {
		int sum = a+b;
		System.out.println("sum of "+a+"+"+b+ " is : "+sum);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex_complie_poly ex = new Ex_complie_poly();
		ex.add(1, 2, 3);
		ex.add(1, 2);
		ex.add(1, 0);

	}

}
