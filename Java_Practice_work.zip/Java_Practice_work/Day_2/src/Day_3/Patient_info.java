package Day_3;

public class Patient_info {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Patient p1 = new Patient();
		
		p1.setPatientId("0001");
        p1.setName("Jack");
        p1.setAge(35);
        p1.setDisease("Fever");
		
        p1.display();
	}

}
