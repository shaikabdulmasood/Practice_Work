package Day_3;

public class Voter_info {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Voter v1 = new Voter();
		v1.setVoterId("V001");
        v1.setName("Anjali");
		
        Voter v2 = new Voter();
        v2.setVoterId("V002");
        v2.setName("Rohan");
        
        Voter v3 = new Voter();
        v3.setVoterId("003");
        v3.setName("Masood");
        
        v1.vote();
        v2.vote();
        v1.vote();
        v2.vote();
        v3.vote();
        
	}

}
