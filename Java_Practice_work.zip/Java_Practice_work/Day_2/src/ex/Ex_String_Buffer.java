package ex;

public class Ex_String_Buffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuffer reciept = new StringBuffer();
		
		reciept.append("************ Customer BILL *****************\n");
		reciept.append("Custmer : Shaik Abdul Masood \n");
		reciept.append("Date: 22-july-2025\n");
		reciept.append("  Item       Qty       Price     Total_Price\n");
		reciept.append("--------------------------------------------\n");
		reciept.append("DairyMilk     2         25.00         50.00\n");
		reciept.append("ButerScotch   3         200.00        600.00\n");
		reciept.append("Kulfi         1         50.00         50.00\n");
		reciept.append("--------------------------------------------\n");
		double total_amount = 50.00+600.00+50.00;
		
		reciept.append("Total Amount :             Rs. "+  total_amount+"\n");
		reciept.append("Thank You For Shopping\n");
		
		reciept.append("*********************************************\n");
		System.out.println(reciept.toString());
		
	}

}
