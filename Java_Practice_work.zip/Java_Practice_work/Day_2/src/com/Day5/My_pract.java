package com.Day5;

public class My_pract {

	public static void main(String[] args){
        short x = 10;
        x =  x * 5;
        System.out.print(x);

	}

}
