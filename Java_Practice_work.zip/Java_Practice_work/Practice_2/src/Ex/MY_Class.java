package Ex;
import java.util.Scanner;
public class MY_Class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Name: ");
		String Name = sc.nextLine();
	}

}
