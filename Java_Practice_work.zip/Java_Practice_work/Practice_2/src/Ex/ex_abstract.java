package Ex;

public class ex_abstract {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("ji");
	}

}
