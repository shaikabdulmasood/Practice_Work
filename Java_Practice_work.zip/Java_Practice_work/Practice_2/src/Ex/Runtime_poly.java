package Ex;

public class Runtime_poly {

	void sound() {
		System.out.println("Hello i am Runtime_poly class");
	}
	
}
class rp extends Runtime_poly{
	
	void sound() {
		System.out.println("HI i am rp class");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Runtime_poly rp = new rp();
		rp.sound();
	}

}

