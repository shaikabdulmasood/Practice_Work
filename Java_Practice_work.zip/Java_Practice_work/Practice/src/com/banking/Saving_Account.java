package com.banking;

public class Saving_Account extends Account {
	
	public Saving_Account(String name,int id, double balance, String branch, String issue_date) {
        super(name,id,balance,branch,issue_date);
    }

	@Override
	void accountType() {
		// TODO Auto-generated method stub
		System.out.println(getName() + "has a Savings Account.");

	}

}
