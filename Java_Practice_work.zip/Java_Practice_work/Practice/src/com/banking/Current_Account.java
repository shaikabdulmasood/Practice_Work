package com.banking;

public class Current_Account extends Account {
	public Current_Account(String name,int acc_no, double balance, String branch, String issue_date) {
        super(name,acc_no, balance,branch,issue_date);
    }

	@Override
	void accountType() {
		// TODO Auto-generated method stub
		System.out.println(getName() + " has a Current Account.");
	}

}
