package com.healthcare;

public interface Patient_Service {

	void register_Patient (Patients patient);
	void show_Patient_Details (int id);
}

