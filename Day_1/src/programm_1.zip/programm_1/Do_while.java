package programm_1;

public class Do_while {

	public static void main(String args[])
	{	
		String [] Fruits = {"Mango","Apple","Banana","Kivi"};
		int [] Price = {60,50,10,40};
		System.out.println("Fruuits are ");
		for(int i = 0; i < Fruits.length ; i++)
		{
			System.out.println(Fruits[i]+" cost is "+Price[i]);
		}
		
	}


}
