package programm_1;

public class Patient_Temp {

	public static void main(String[] args) {
		
		

	}

}
