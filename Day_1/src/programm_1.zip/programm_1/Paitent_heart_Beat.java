package programm_1;

public class Paitent_heart_Beat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		do
		{
			
		}

	}

}
