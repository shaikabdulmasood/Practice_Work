package com.banking;

public interface Account_Service {
	void registerAccount(Account account);
    void showAllAccounts(Account account);

}
