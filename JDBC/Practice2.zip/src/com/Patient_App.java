package com;

public class Patient_App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
