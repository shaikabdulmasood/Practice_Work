package com;

public class Wrapper_Class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num = 10;
		 
		Integer obj = num;
		//System.out.println(type(obj));
		
		//System.out.println("type is: "+ num.getClass().getName()); 
		System.out.println("num Type is: "+ obj.getClass().getName());

	}

}
