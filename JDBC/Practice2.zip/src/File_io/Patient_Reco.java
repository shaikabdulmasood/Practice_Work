package File_io;

public class Patient_Reco {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
