/**
 * 
 */
/**
 * 
 */
module Practice {
	requires java.sql;
}